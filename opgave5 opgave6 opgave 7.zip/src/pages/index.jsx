import React from 'react';

function Index() {
    return (
        <>
            <main>
                <h1>Hjem</h1>
            </main>
        </>
    );
}

export default Index;
